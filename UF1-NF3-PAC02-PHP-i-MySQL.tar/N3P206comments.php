<html>
    <head>
    <title>Documento</title>
    <body>
        <ol>
            <li>He aprendido el select *from en sql</li>
            <li>Como iniciar un terminal sql</li>
            <li>Como ver las tablas en sql</li>
            <li>Como acceder en root a sql</li>
            <li>Como crear tablas en php</li>
            <li>Como crear relaciones en php</li>
            <li>Hacer que podamos acceder a diferentes páginas dentro de una</li>
            <li>Como insertar datos en una tabla en php</li>
            <li>usar el alter table en php</li>
            <li>aprender como usar comando para conectarse a la base de datos en php</li>
        </ol>
        <p>Documento 6 y la explicación del profe un 7</p>
        <p>8</p>
        <p>Quizá hacer los ejercicios más intuitivos y no tan rebuscados como era el 3</p>
    </body>
    </head>
</html>
